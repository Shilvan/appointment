A Pen created at CodePen.io. You can find this one at http://codepen.io/RicardoBarbosa/pen/kXzRbw.

 Calendar using ReactJs (beginner level), idea from @AJALACOMFORT modified by me