/*

Colors & layout inspiration from:
+ http://dribbble.com/shots/1054042--Freebie-Calendar-Window?list=searches&tag=calendar
+ http://dribbble.com/shots/1054880-My-Birfday-Calendar

*/